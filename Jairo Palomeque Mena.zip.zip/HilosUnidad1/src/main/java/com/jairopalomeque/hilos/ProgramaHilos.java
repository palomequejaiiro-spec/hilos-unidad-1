package com.jairopalomeque.hilos;

import java.util.Scanner;

// Hilo 1: Conteo regresivo
class HiloConteo extends Thread {
    private int numero;

    public HiloConteo(int numero) {
        this.numero = numero;
        setName("Conteo");
    }

    @Override
    public void run() {
        try {
            for (int i = numero; i >= 0; i--) {
                System.out.println("[Hilo " + getName() + "] Conteo: " + i);
                Thread.sleep(500);
            }
            System.out.println("Trabajo del hilo " + getName() + " terminado");
        } catch (InterruptedException e) {
            System.out.println("Hilo interrumpido");
        }
    }
}

// Hilo 2: Alfabeto
class HiloAlfabeto extends Thread {
    private char letraFinal;

    public HiloAlfabeto(char letraFinal) {
        this.letraFinal = letraFinal;
        setName("Alfabeto");
    }

    @Override
    public void run() {
        try {
            for (char c = 'A'; c <= letraFinal; c++) {
                System.out.println("[Hilo " + getName() + "] Letra: " + c);
                Thread.sleep(600);
            }
            System.out.println("Trabajo del hilo " + getName() + " terminado");
        } catch (InterruptedException e) {
            System.out.println("Hilo interrumpido");
        }
    }
}

// Clase principal
public class ProgramaHilos {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        int numero;
        char letra;

        // Validación número
        do {
            System.out.print("Ingrese un número entero positivo: ");
            while (!sc.hasNextInt()) {
                System.out.print("Error. Ingrese un número válido: ");
                sc.next();
            }
            numero = sc.nextInt();
        } while (numero <= 0);

        // Validación letra
        do {
            System.out.print("Ingrese una letra entre A y Z: ");
            letra = sc.next().toUpperCase().charAt(0);
        } while (letra < 'A' || letra > 'Z');

        System.out.println("\n--- INICIO DE LOS HILOS ---\n");

        HiloConteo hilo1 = new HiloConteo(numero);
        HiloAlfabeto hilo2 = new HiloAlfabeto(letra);

        hilo1.start();
        hilo2.start();

        sc.close();
    }
}
